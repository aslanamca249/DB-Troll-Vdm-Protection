fx_version 'cerulean'
game 'gta5'
lua54 "evet"

author 'DB Development'
description 'VDM Protection Script'
version '1.0.0'

client_scripts {
    'vdm.lua'
}

dependency '/assetpacks'